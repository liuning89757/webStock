# -*- coding: utf8 -*-

import socket
import time
from threading import Thread

from thread import SocketIoThread


class SocketServer:
    def __init__(self,port,IO):
        self.io = IO
        self.io.setServer(self)
        self.uid = 0
        self.port = port
        self.IoList = {}
	# 事件处理线程
	self.__thread = Thread(target = self.__run)
	
    def __run(self):
        sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        sock.bind(('',self.port))
        sock.listen(100)

        while True:
            try:
                connection,address = sock.accept()
                #print "UID:",self.uid
                self.uid += 1
                self.IoList[self.uid] = SocketIoThread(connection,self.uid,self.io)
                self.IoList[self.uid].start()
            except:
		        time.sleep(1)
			
    def start(self):
	self.__thread.start()
            
    def sendData(self,uid,text):
        if self.IoList.has_key(uid):
            print uid,text
            self.IoList[uid].sendData(text)
        


            


